Running Instructions
Download and extract the folder to a desired destination
Type in ‘make’ in your terminal to generate the necessary files on your computer,
You may delete the files with the extension '.o' to further test this and the 'add' file too
After this type in './add' to begin the program
You may type in any thing of this format
x + y
x * y
x ^ y
log(x)
exp(x)
You may combine the above as you wish
Program does not parse nested functions : log of exponent or exponent of log
Typing anything else will generate a syntax error and exit the program
The other way to exit the program is to type in control + c
The program recognizes all input as floats

Special Cases Example: log((exp(2+2))) returns 4
